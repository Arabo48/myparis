// Loads homepage stats and featured content from Supabase.
// Every count/list here is a real query, not placeholder data
// (Section 45: no fake UI).

import { supabase } from './supabase-client.js';

async function loadStats() {
  const [{ count: members }, { count: skills }, { count: projects }, { count: opportunities }] =
    await Promise.all([
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
      supabase.from('skills').select('id', { count: 'exact', head: true }),
      supabase.from('projects').select('id', { count: 'exact', head: true }),
      supabase.from('opportunities').select('id', { count: 'exact', head: true }).eq('is_approved', true),
    ]);

  setText('statMembers', members ?? 0);
  setText('statSkills', skills ?? 0);
  setText('statProjects', projects ?? 0);
  setText('statOpportunities', opportunities ?? 0);
}

async function loadFeaturedMembers() {
  const { data, error } = await supabase
    .from('profiles')
    .select('username, full_name, professional_headline, profile_photo_url, is_verified')
    .eq('profile_visibility', 'public')
    .eq('is_verified', true)
    .order('created_at', { ascending: false })
    .limit(6);

  const grid = document.getElementById('featuredMembersGrid');
  if (error || !data || data.length === 0) {
    grid.innerHTML = '<p class="placeholder-text">No featured members yet — be the first to join and get verified!</p>';
    return;
  }

  grid.innerHTML = data.map(m => `
    <a class="member-card" href="/members/${encodeURIComponent(m.username)}">
      <img src="${m.profile_photo_url || '/images/default-avatar.png'}" alt="" class="avatar" />
      <h3>${escapeHtml(m.full_name)} ${m.is_verified ? '✅' : ''}</h3>
      <p>${escapeHtml(m.professional_headline || '')}</p>
    </a>
  `).join('');
}

async function loadRecentProjects() {
  const { data, error } = await supabase
    .from('projects')
    .select('title, slug, description, image_url, status')
    .order('created_at', { ascending: false })
    .limit(6);

  const grid = document.getElementById('recentProjectsGrid');
  if (error || !data || data.length === 0) {
    grid.innerHTML = '<p class="placeholder-text">No projects have been published yet.</p>';
    return;
  }

  grid.innerHTML = data.map(p => `
    <a class="project-card" href="/projects/${encodeURIComponent(p.slug)}">
      <img src="${p.image_url || '/images/default-project.png'}" alt="" />
      <h3>${escapeHtml(p.title)}</h3>
      <span class="status-badge status-${p.status}">${p.status.replace('_', ' ')}</span>
    </a>
  `).join('');
}

async function loadUpcomingEvents() {
  const today = new Date().toISOString().slice(0, 10);
  const { data, error } = await supabase
    .from('events')
    .select('name, slug, event_date, location')
    .gte('event_date', today)
    .order('event_date', { ascending: true })
    .limit(4);

  const grid = document.getElementById('upcomingEventsGrid');
  if (error || !data || data.length === 0) {
    grid.innerHTML = '<p class="placeholder-text">No upcoming events scheduled yet.</p>';
    return;
  }

  grid.innerHTML = data.map(e => `
    <a class="event-card" href="/events/${encodeURIComponent(e.slug)}">
      <h3>${escapeHtml(e.name)}</h3>
      <p>${e.event_date} — ${escapeHtml(e.location || 'TBA')}</p>
    </a>
  `).join('');
}

async function loadPlatformName() {
  const { data } = await supabase.from('platform_settings').select('platform_name').limit(1).maybeSingle();
  if (data?.platform_name) {
    document.title = data.platform_name;
    const brand = document.getElementById('brand-name');
    if (brand) brand.textContent = data.platform_name;
  }
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

loadPlatformName();
loadStats();
loadFeaturedMembers();
loadRecentProjects();
loadUpcomingEvents();
