# MY TOWN DIGITAL &amp; TECH COMMUNITY

A full-stack platform for discovering, showcasing and connecting young
digital & tech talent in a local community — profiles, skills,
projects, services, opportunities, events, mentorship, and an admin
system to run it all.

**Stack:** HTML5 / CSS3 / vanilla JS frontend, Supabase (PostgreSQL +
Auth + Storage) backend. Deployable to Netlify or Vercel.

---

## ✅ Phase 1 — what's built so far

- Project structure and build tooling
- Complete PostgreSQL schema (23 tables) with enums, indexes, and
  triggers — `database/migrations/001_initial_schema.sql`
- Auto-provisioning of a `profiles` row on signup —
  `database/migrations/002_auth_trigger.sql`
- Secure first-super-admin setup procedure (no public "make me admin"
  button anywhere) — `database/migrations/003_super_admin_setup.sql`
- Demo/seed data for skills, categories and neighborhoods, all
  removable in one query — `database/migrations/004_seed_data.sql`
- Row Level Security policies on every table (see schema file, Section
  17) enforcing:
  - Users can only edit their own profile, and can't change their own
    `role` or verification status
  - Only admins can verify, suspend, or change roles
  - Only admins (or approved organizations) can post opportunities
  - Everything else follows least-privilege by default
- Supabase client + auth module (register, login, logout, password
  reset, session/role guard) — `assets/js/supabase-client.js`,
  `assets/js/auth.js`
- Working homepage pulling **live** stats and featured content from
  the database (no fake numbers) — `index.html`, `assets/js/home.js`
- Working registration and login pages wired to real Supabase Auth
- Member dashboard and Admin dashboard skeletons, both gated by
  `requireRole()` and pulling real counts

## ✅ Phase 2 — what's built

- Public member profile page respecting per-field privacy settings
  (phone/email/location/socials/portfolio each independently
  public/members-only/private) — `pages/public/member-profile.html`
- Member profile edit form wired to real `profiles` updates — never
  sends `role`/`is_verified`/`verification_status`, and RLS blocks
  those columns server-side even if it tried —
  `pages/member/profile.html`
- Public skills directory grouped by category, each skill linking into
  filtered search — `pages/public/skills.html`
- Member's own skill management (add/remove real rows in
  `member_skills`) — `pages/member/skills.html`
- Full member search/discovery page: text search, skill filter,
  category filter, experience level, availability, professional
  status, sorting, and real pagination (12/page) —
  `pages/public/members.html`

## ✅ Phase 3 — what's built

- Member project management: create/edit/delete with auto-generated
  unique slugs, technologies list, status, links —
  `pages/member/projects.html`
- Public project showcase (filter by status, sort) and project detail
  page (privacy-safe: only ever shows what's actually in the DB, no
  fake team members or stats) — `pages/public/projects.html`,
  `pages/public/project-detail.html`
- Member services management (create/edit/delete, active/inactive
  toggle) — `pages/member/services.html`
- Public searchable services marketplace —
  `pages/public/services.html`
- Member achievements (add/delete), each showing real verification
  status pulled from `verification_status` — `pages/member/achievements.html`
- Verification request flow: members submit a request from Settings,
  it lands in `verification_requests` as `pending`; only admins can
  change its status (RLS-enforced) — `pages/member/settings.html`
- Password reset request wired into Settings

## 🚧 Not built yet (next phases)

- Phase 4: opportunities & events CRUD, mentorship request flow
- Phase 5: notifications UI, contact/hire form, reports UI, announcements UI
- Phase 6: full admin member/content management tables, audit log viewer, settings page
- Phase 7: security review, performance pass, SEO polish, full test pass

Each phase builds directly on this Phase 1 foundation — nothing here
needs to be redone.

---

## Setup

### 1. Create a Supabase project
Go to [supabase.com](https://supabase.com), create a new project, and
note your **Project URL** and **anon/public key** (Project Settings →
API). Never use the `service_role` key in any frontend file.

### 2. Run the database migrations
In the Supabase SQL Editor, run these files **in order**:
1. `database/migrations/001_initial_schema.sql`
2. `database/migrations/002_auth_trigger.sql`
3. `database/migrations/004_seed_data.sql` (optional, demo lookup data)

Do **not** run `003_super_admin_setup.sql` yet — see step 5.

### 3. Configure environment variables
Copy `.env.example` to `.env` and fill in your project's URL and anon
key. Locally:

```bash
npm install
SUPABASE_URL=https://YOUR-REF.supabase.co SUPABASE_ANON_KEY=your-anon-key npm run dev
```

On Netlify/Vercel, set `SUPABASE_URL` and `SUPABASE_ANON_KEY` as
environment variables in the dashboard — the build command
(`npm run build`) generates `assets/js/env-config.js` automatically at
deploy time. This file is git-ignored and never committed.

### 4. Enable email auth
In Supabase Dashboard → Authentication → Providers, confirm
Email is enabled. Under Authentication → URL Configuration, set your
site URL (e.g. your Netlify domain) so confirmation/reset emails link
back correctly.

### 5. Create your first Super Administrator
1. Register a real account through `/pages/public/register.html`.
2. In Supabase SQL Editor, find its id:
   ```sql
   select id, email from auth.users where email = 'you@example.com';
   ```
3. Open `database/migrations/003_super_admin_setup.sql`, paste that id
   in, and run it. This is the only sanctioned way to create an admin
   — there is no in-app mechanism for it, by design (Section 37).

### 6. Deploy
- **Netlify:** connect the repo, build command `npm run build`,
  publish directory `.`. `netlify.toml` already defines pretty URLs
  for `/members/:username`, `/projects/:slug`, `/opportunities/:slug`,
  `/events/:slug`.
- **Vercel:** import the repo, set the same environment variables,
  build command `npm run build`, output directory `.`.

---

## Local development

```bash
npm install
npm run dev
```

This regenerates `assets/js/env-config.js` from your local environment
variables and serves the project at `http://localhost:3000`.

---

## Project structure

```
/database/migrations   SQL migrations, run in numeric order
/assets/css            Stylesheets (main, forms, dashboard)
/assets/js             supabase-client.js, auth.js, page scripts
/pages/public           Homepage-adjacent public pages (login, register, ...)
/pages/member           Member dashboard & tools
/pages/admin            Admin dashboard & management tools
/scripts               Build-time helpers (env injection)
index.html             Homepage
```

## Security notes

- RLS is enabled on every table; the frontend is never the only line
  of defense.
- The anon key is safe to expose (it's designed to be) — RLS is what
  actually restricts access. The `service_role` key must never appear
  in any file under `/assets`, `/pages`, or anywhere shipped to the
  browser.
- Role changes, verification, and suspensions are only possible via
  admin-gated policies (`is_admin()` in SQL) — a member editing their
  own profile cannot smuggle in a role or verification change even by
  calling the API directly.
